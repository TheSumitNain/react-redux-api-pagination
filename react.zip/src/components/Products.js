import React, { useEffect, useState } from "react";
import "../css/products.css";
import { useDispatch, useSelector } from "react-redux";
import { addToCart } from "../redux/rootReducer";

const Products = () => {
  const [data, setData] = useState([]);
  const state = useSelector((state) => state.counterSlice.productData);
  console.log(state);

  const dispatch = useDispatch();

  const apiData = async () => {
    const result = await fetch("https://fakestoreapi.com/products");
    const res = await result.json();
    setData(res);
    console.log(res);
  };

  useEffect(() => {
    apiData();
  }, []);

  return (
    <>
      <div className="products_main">
        <div className="card">
            {
                data.map((item) => {
                  return <div className="card_inner">
                       <div className="item_pic_div">
                        <img src={item.image} alt="image" />
                       </div>
                       <h3> {item.title.slice(0, 25)} </h3>
                       <p> {item.description.slice(0, 60)} </p>
                       <div className="price_category">
                       <p> Category: {item.category}</p>
                        <p> Price: ${item.price} </p>
                       </div>
                       <button onClick={() => dispatch(addToCart({
                        id:item.id,
                        title: item.title,
                        image: item.image,
                        description: item.description,
                        category: item.category,
                        quantity: 1,
                       }))}>
                       Add to cart</button>
                  </div>
                })
            }
        </div>
      </div>
    </>
  );
};

export default Products;
